package ca.on.senecac.ict.cfops;

import android.app.ActionBar;
import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import ca.on.senecac.ict.cfops.CFOpsXmlParser.Op;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class ResultActivity extends Activity
        implements SearchView.OnQueryTextListener {
    RecyclerView recyclerView;
    ResultRecyclerAdapter adapter;
    ResultRecyclerAdapter filtered;
    ProcessXmlTask processXmlTask;
//    ProgressBar progress;

    private static final String TAG = "CFOPs";
    private final String JSON_URL =
            "http://open.canada.ca/data/api/action/package_show?id=c3893f29-43c7-4f34-ac7e-3ee8aefc2af1";
    private final String URL_STR =
            "http://www.cmp-cpm.forces.gc.ca/dhh-dhp/data/CF_Operations_20140109.xml";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

//        progress = (ProgressBar) findViewById(R.id.progressBar);
//        recyclerView = (RecyclerView) findViewById(R.id.result_view);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(ResultActivity.this);
//        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setLayoutManager(new GridLayoutManager(ResultActivity.this, 1));
        processXmlTask = new ProcessXmlTask();
//        processXmlTask.execute(URL_STR);
        processXmlTask.execute(JSON_URL);
    }

    private class ProcessXmlTask extends AsyncTask<String, Void, List<Op>> {
        @Override
        protected List<Op> doInBackground(String... jsonUrls) {
            String xmlUrl = getDownloadLink(jsonUrls[0]);
            if (xmlUrl == null)
                xmlUrl = URL_STR;

            // parse dataset
            List<Op> ops = new ArrayList<>();
            HttpURLConnection conn = null;
            try {
                URL url = new URL(xmlUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.connect();
                CFOpsXmlParser parser = new CFOpsXmlParser();
                ops = parser.parse(conn.getInputStream());
            } catch (MalformedURLException e) {

            } catch (IOException e) {
//                return getResources().getString(R.string.connection_error);
            } catch (XmlPullParserException e) {
//                return getResources().getString(R.string.xml_error);
            } finally {
                if (conn != null)
                    conn.disconnect();
            }

            return ops;
        }

        @Override
        protected void onPostExecute(List<Op> result) {
//            progress.setVisibility(View.INVISIBLE);

            if (result == null || result.size() == 0) {
                Toast.makeText(getApplicationContext(),
                        "Lookup failed", Toast.LENGTH_LONG).show();
                return;
            }
            recyclerView = (RecyclerView) findViewById(R.id.result_view);
            LinearLayoutManager layoutManager = new LinearLayoutManager(ResultActivity.this);
            layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            recyclerView.setLayoutManager(layoutManager);
            filtered = adapter = new ResultRecyclerAdapter(ResultActivity.this, result);
            recyclerView.setAdapter(filtered);
        }

//        @Override
//        protected void onPreExecute() {
//            Log.i(TAG, "onPreExecute");
//            //Display progress bar
//            progress.setVisibility(View.VISIBLE);
//        }
//
//        @Override
//        protected void onProgressUpdate(Void... values) {
//            Log.i(TAG, "onProgressUpdate");
//        }

        // get dataset download link for JSON url
        private String getDownloadLink(String jsonUrl) {
            StringBuilder stringBuilder = new StringBuilder();
            HttpClient client = new DefaultHttpClient();
            HttpGet httpGet = new HttpGet(jsonUrl);
            try {
                HttpResponse response = client.execute(httpGet);
                StatusLine statusLine = response.getStatusLine();
                int statusCode = statusLine.getStatusCode();
                if (statusCode == 200) {
                    HttpEntity entity = response.getEntity();
                    InputStream content = entity.getContent();
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(content));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                } else {
                    Log.e(TAG, "Failed to extract download link");
                }
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            String xmlUrl = null;
            try {
                JSONObject object =
                        (JSONObject) new JSONObject(stringBuilder.toString());
                JSONArray resources = object.getJSONObject("result")
                                            .getJSONArray("resources");
                xmlUrl = resources.getJSONObject(0).getString("url");
                Log.i(TAG, "Got download link");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return xmlUrl;
        }
    }

    public boolean onQueryTextChange(String newText) {
        filtered.getFilter().filter(newText);
        return true;
    }

    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_result, menu);

        SearchView searchView = (SearchView) menu.findItem(R.id.action_search).getActionView();
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView.setSearchableInfo(
            searchManager.getSearchableInfo(getComponentName()));
        searchView.setOnQueryTextListener(this);
//        searchView.setSubmitButtonEnabled(true);
        searchView.setIconifiedByDefault(true);
        searchView.setQueryHint(getResources().getString(R.string.search_hint));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
