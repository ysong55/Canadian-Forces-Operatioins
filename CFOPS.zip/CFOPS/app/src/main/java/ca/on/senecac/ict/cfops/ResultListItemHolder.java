package ca.on.senecac.ict.cfops;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by ys on 4/3/2015.
 */
public class ResultListItemHolder extends RecyclerView.ViewHolder {
    protected ImageView imageView;
    protected TextView op_name_ca;
    protected TextView op_name_international;
    protected TextView location;
    protected TextView start_date;
    protected TextView end_date;

    public ResultListItemHolder(View view) {
        super(view);
        this.imageView = (ImageView) view.findViewById(R.id.imageView);
        this.op_name_ca = (TextView) view.findViewById(R.id.op_name_ca);
        this.op_name_international = (TextView) view.findViewById(R.id.op_name_international);
        this.location = (TextView) view.findViewById(R.id.location);
        this.start_date = (TextView) view.findViewById(R.id.start_date);
        this.end_date = (TextView) view.findViewById(R.id.end_date);
    }

}
