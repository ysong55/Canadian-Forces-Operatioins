package ca.on.senecac.ict.cfops;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by ys on 4/3/2015.
 */
public class CFOpsXmlParser {
    private static SimpleDateFormat dateTimeParser =
            new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    private static SimpleDateFormat dateTimeFormatter =
            new SimpleDateFormat("MMMM dd, yyyy");

    // We don't use namespaces
    private static final String ns = null;

    public List<Op> parse(InputStream in)
            throws XmlPullParserException, IOException {
        XmlPullParser parser = Xml.newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        parser.setInput(in, null);
        parser.nextTag();
        return readDataset(parser);
    }

    private List<Op> readDataset(XmlPullParser parser)
            throws XmlPullParserException, IOException {
        List<Op> entries = new ArrayList<>();

        parser.require(XmlPullParser.START_TAG, ns, "xml");
        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            // Starts by looking for the row tag
            if (name.equals("row")) {
                entries.add(readOp(parser));
            } else {
                skip(parser);
            }
        }
        return entries;
    }

    // Parses the contents of a row. If it encounters
    // a CFOpName_e, IntlOpName_e, or Location_e tag, hands them
    // off to their respective &quot;read&quot; methods for processing.
    // Otherwise, skips the tag.
    private Op readOp(XmlPullParser parser)
            throws XmlPullParserException, IOException {
        parser.require(XmlPullParser.START_TAG, ns, "row");
        String cFOpName_e = "";
        String intlOpName_e = "";
        String location_e = "";
        String intlStartDate = "";
        String intlEndDate = "";

        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            if (name.equals("CFOpName_e")) {
                cFOpName_e = readCFOpName_e(parser);
            } else if (name.equals("IntlOpName_e")) {
                intlOpName_e = readIntlOpName_e(parser);
            } else if (name.equals("Location_e")) {
                location_e = readLocation_e(parser);
            } else if (name.equals("IntlStartDate")) {
                intlStartDate = readIntlStartDate(parser);
            } else if (name.equals("IntlEndDate")) {
                intlEndDate = readIntlEndDate(parser);
            } else {
                skip(parser);
            }
        }

        try {
            if (intlStartDate != null && intlStartDate.length() != 0) {
                Date start = dateTimeParser.parse(intlStartDate);
                intlStartDate = dateTimeFormatter.format(start);
            }

            if (intlEndDate != null && intlEndDate.length() != 0) {
                Date end = dateTimeParser.parse(intlEndDate);
                intlEndDate = dateTimeFormatter.format(end);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return new Op(cFOpName_e, intlOpName_e, location_e,
                        intlStartDate, intlEndDate);
    }

    // Processes CFOpName_e tags in the xml.
    private String readCFOpName_e(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "CFOpName_e");
        String cFOpName_e = readText(parser);
        parser.require(XmlPullParser.END_TAG, ns, "CFOpName_e");
        return cFOpName_e;
    }

    // Processes IntlOpName_e tags in the xml.
    private String readIntlOpName_e(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "IntlOpName_e");
        String intlOpName_e = readText(parser);
        parser.require(XmlPullParser.END_TAG, ns, "IntlOpName_e");
        return intlOpName_e;
    }

    // Processes Location_e tags in the xml.
    private String readLocation_e(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "Location_e");
        String location_e = readText(parser);
        parser.require(XmlPullParser.END_TAG, ns, "Location_e");
        return location_e;
    }

    // Processes IntlStartDate tags in the xml.
    private String readIntlStartDate(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "IntlStartDate");
        String intlStartDate = readText(parser);
        parser.require(XmlPullParser.END_TAG, ns, "IntlStartDate");
        return intlStartDate;
    }

    // Processes IntlEndDate tags in the xml.
    private String readIntlEndDate(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "IntlEndDate");
        String intlEndDate = readText(parser);
        parser.require(XmlPullParser.END_TAG, ns, "IntlEndDate");
        return intlEndDate;
    }

    // For the tags IntlOpName_e and Location_e, extracts their text values.
    private String readText(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        String result = "";
        if (parser.next() == XmlPullParser.TEXT) {
            result = parser.getText().trim();
            parser.nextTag();
        }
        return result;
    }

    // Skips tags the parser isn't interested in. Uses depth to handle nested tags. i.e.,
    // if the next tag after a START_TAG isn't a matching END_TAG, it keeps going until it
    // finds the matching END_TAG (as indicated by the value of "depth" being 0).
    private void skip(XmlPullParser parser)
            throws XmlPullParserException, IOException {
        if (parser.getEventType() != XmlPullParser.START_TAG) {
            throw new IllegalStateException();
        }
        int depth = 1;
        while (depth != 0) {
            switch (parser.next()) {
                case XmlPullParser.END_TAG:
                    depth--;
                    break;
                case XmlPullParser.START_TAG:
                    depth++;
                    break;
            }
        }
    }

    // This class represents a single row (op) in the XML xml.
    public static class Op {
        private String cFOpName_e;
        private String intlOpName_e;
        private String location_e;
        private String intlStartDate;
        private String intlEndDate;

        private Op(String cFOpName_e, String intlOpName_e, String location_e,
                   String intlStartDate, String intlEndDate) {
            this.cFOpName_e = cFOpName_e;
            this.intlOpName_e = intlOpName_e;
            this.location_e = location_e;
            this.intlStartDate = intlStartDate;
            this.intlEndDate = intlEndDate;
        }

        public String getCFOpName_e() {
            return cFOpName_e;
        }

        public String getIntlOpName_e() {
            return intlOpName_e;
        }

        public String getLocation_e() {
            return location_e;
        }

        public String getIntlStartDate() {
            return intlStartDate;
        }

        public String getIntlEndDate() {
            return intlEndDate;
        }

        @Override
        public String toString() {
            return cFOpName_e + "\n" + intlOpName_e + "\n" + location_e + ' ' +
                    intlStartDate + " -- " + intlEndDate;
        }
    }
}
