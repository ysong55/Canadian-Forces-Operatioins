package ca.on.senecac.ict.cfops;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ca.on.senecac.ict.cfops.CFOpsXmlParser.Op;

/**
 * Created by ys on 4/3/2015.
 */
public class ResultRecyclerAdapter
        extends RecyclerView.Adapter<ResultListItemHolder>
        implements Filterable {
    private List<Op> itemList;
    private List<Op> itemListFull;
    private Context context;

    public ResultRecyclerAdapter(Context context, List<Op> itemList) {
        this.context = context;
        this.itemListFull = this.itemList = itemList;
    }

    @Override
    public ResultListItemHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View itemView =
                LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.result_row,
                        viewGroup, false);
        return new ResultListItemHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ResultListItemHolder resultListItemHolder, int position) {
        Op resultItem = itemList.get(position);
        resultListItemHolder.imageView.setImageResource(R.drawable.ic_caf);
        resultListItemHolder.op_name_ca.setText(resultItem.getCFOpName_e());
        resultListItemHolder.op_name_international.setText(resultItem.getIntlOpName_e());
        resultListItemHolder.location.setText(resultItem.getLocation_e());
        resultListItemHolder.start_date.setText(resultItem.getIntlStartDate());
        resultListItemHolder.end_date.setText(resultItem.getIntlEndDate());
    }

    @Override
    public int getItemCount() {
        return (null != itemList ? itemList.size() : 0);
    }

    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();

                if (constraint == null) {
                    filterResults.values = itemList;
                    return filterResults;
                }

                List<Op> results = new ArrayList<>();
                String query = constraint.toString().trim();
                if (query.length() != 0) {
                    String[] kw = query.split(" ");
                    for (Op s : itemListFull) {
                        String opDetails = s.toString().toLowerCase();
                        int match = 0;
                        for (String k : kw) {
                            if (opDetails.contains(k))
                                match += 1;
                        }
                        if (match == kw.length)
                            results.add(s);
                    }
                    filterResults.values = results;
                } else {
                    filterResults.values = itemListFull;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {

//                if (results == null/* || results.count == 0*/) {
//                    Toast.makeText(context, "No match!", Toast.LENGTH_LONG).show();
//                    return;
//                }
//                Toast.makeText(context,
//                        (results == null ? 0 : results.count) + " matches!",
//                        Toast.LENGTH_LONG).show();
                itemList = (List<Op>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}